//
//  DocereeMobileAds.h
//  DocereeMobileAds
//
//  Created by dushyant pawar on 11/05/20.
//  Copyright © 2020 Doceree. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for DocereeMobileAds.
FOUNDATION_EXPORT double DocereeMobileAdsVersionNumber;

//! Project version string for DocereeMobileAds.
FOUNDATION_EXPORT const unsigned char DocereeMobileAdsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DocereeMobileAds/PublicHeader.h>


